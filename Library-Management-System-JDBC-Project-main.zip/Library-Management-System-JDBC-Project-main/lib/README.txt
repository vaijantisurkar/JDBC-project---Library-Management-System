Place mysql-connector-java.jar here (rename to mysql-connector-java.jar). Download from dev.mysql.com/downloads/connector/j/
